"""Exponential"""
from constants import e


def exp(x) -> float:
    return e**x
